import numpy as np
import cv2


import os
import time
import smtplib
import sys


	

def sendEmail():

	
	print "Sending email...."
	gmail_user = 'username@gmail.com'  
	gmail_password = 'pwd'

	sent_from = gmail_user  
	to = ['receivingend@gmail.com']  
	subject = 'OMG Super Important Message'  
	body = 'Hey, what is up??'

	email_text = """\  
	From: %s  
	To: %s  
	Subject: %s

	%s
	""" % (sent_from, ", ".join(to), subject, body)

	try:  
	    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
	    server.ehlo()
	    server.login(gmail_user, gmail_password)
	    server.sendmail(sent_from, to, email_text)
	    server.close()

	    print 'Email sent!'
	except:  
	    print 'Something went wrong...'


def checkProb(list1):
	length = len(list1)
	count = 0
	for i in list1:
		if(i == 1):
			count +=1
	if(count/float(length)> 0.7):
		sendEmail()
		sys.exit()
	
	
def recognize():
	count = 0
	predList = []
	face_detect = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
	cap = cv2.VideoCapture(0)

	recognizer = cv2.createLBPHFaceRecognizer()
	recognizer.load('trainingData.yml')
	font = cv2.FONT_HERSHEY_COMPLEX_SMALL
	user = raw_input('Do u want to try an image ? (y/n)')

	if(user == 'n'):
		countCorrect = 0
		countFaces = 0
		while True:
		    ret, frame = cap.read()
		    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
		    faces = face_detect.detectMultiScale(gray, 1.3, 5)
		    for (x,y,w,h) in faces:
			cv2.rectangle(frame, (x,y), (x+w,y+h), (255, 0, 0), 4)
			id, conf = recognizer.predict(gray[y:y+h, x:x+w])
			print id
	
	
			#cv2.putText(frame, string,(x,y+h),font,4,(0,0,255), 2, cv2.CV_AA)
		    cv2.imshow('face', frame)
		    if(cv2.waitKey(10) & 0xff == 27):
			break

		cap.release()
		cv2.destroyAllWindows()

	else:
		filename = raw_input('Please enter the file name: ')
	
		frame = cv2.imread(filename,0)
		    
		    
		id, conf = recognizer.predict(frame)
	
		predList.append(id)
		count+=1

		if(count == 5):
			checkProb(predList)
			count = 0
			predList = []


recognize()


		

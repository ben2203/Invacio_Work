# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.template import loader
from django.shortcuts import render
from django.http import HttpResponse
from .models import Camera

# Create your views here.

def index(request):
    email=Camera.objects.all()
    context = {
        'email':email,
    }

    return render(request,'camera_control/models.html',context)
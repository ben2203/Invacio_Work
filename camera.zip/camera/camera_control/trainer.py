import os
import cv2 
import numpy as np
from PIL import Image

def getImagesWithId():
    imagePaths = ['0','1']
    faces = []
    IDs = []
    
    for i in [0,1]:
	    imagePaths = os.listdir(str(i))
	    for imagePath in imagePaths:
		
		faceNp = cv2.imread(str(i)+'/'+ imagePath,0)
		IDs.append(i)
		faces.append(faceNp)
		
		cv2.imshow('training', faceNp)
		cv2.waitKey(1)
    
    return faces, np.array(IDs)

if __name__ == '__main__':
	recognizer = cv2.createLBPHFaceRecognizer()

	faces, IDs = getImagesWithId()
	print ("Training in progess")
	recognizer.train(faces, IDs)
	print ("Training done")
	recognizer.save('trainingData.yml')
	cv2.destroyAllWindows()
